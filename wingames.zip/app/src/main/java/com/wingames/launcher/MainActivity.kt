package com.wingames.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {

    private val pickGameCode = 101
    private val match = ViewGroup.LayoutParams.MATCH_PARENT
    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var grid: GridLayout
    private lateinit var emptyText: TextView
    private val games = mutableListOf<Game>()

    data class Game(val name: String, val uri: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadGames()
        buildUi()
        refresh()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#12121A"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }

        val title = TextView(this).apply {
            text = "WinGames"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }

        emptyText = TextView(this).apply {
            text = "Library is empty.\nTap Download and pick a game file."
            setTextColor(Color.parseColor("#9AA0B4"))
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, dp(60), 0, 0)
        }

        grid = GridLayout(this).apply { columnCount = 3 }
        val scroll = ScrollView(this).apply { addView(grid) }

        val downloadBtn = Button(this).apply {
            text = "Download"
            textSize = 16f
            setOnClickListener { pickGame() }
        }

        root.addView(title)
        root.addView(emptyText, LinearLayout.LayoutParams(match, wrap))
        root.addView(scroll, LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(downloadBtn, LinearLayout.LayoutParams(match, dp(56)))
        setContentView(root)
    }

    // Opens the phone's Files app so the user can pick a downloaded game
    private fun pickGame() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        startActivityForResult(intent, pickGameCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickGameCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
                // some providers do not allow persistable permission
            }
            val name = queryName(uri).substringBeforeLast('.')
            if (games.none { it.uri == uri.toString() }) {
                games.add(Game(name, uri.toString()))
                saveGames()
            }
            refresh()
        }
    }

    private fun queryName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) return c.getString(idx)
        }
        return "Game"
    }

    private fun refresh() {
        grid.removeAllViews()
        emptyText.visibility = if (games.isEmpty()) View.VISIBLE else View.GONE
        val colors = listOf("#E94560", "#0F9D8A", "#5B6CFF", "#F5A623", "#9B59B6", "#2ECC71")

        games.forEachIndexed { index, g ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(6), dp(10), dp(6), dp(10))
                setOnClickListener { showGame(g) }
            }

            val logo = TextView(this).apply {
                text = g.name.take(1).uppercase()
                textSize = 28f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(Color.parseColor(colors[index % colors.size]))
                }
            }
            tile.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))

            val label = TextView(this).apply {
                text = g.name
                setTextColor(Color.WHITE)
                textSize = 12f
                gravity = Gravity.CENTER
                maxLines = 2
            }
            tile.addView(label, LinearLayout.LayoutParams(dp(90), wrap))

            val lp = GridLayout.LayoutParams().apply {
                width = 0
                height = wrap
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            grid.addView(tile, lp)
        }
    }

    private fun showGame(g: Game) {
        AlertDialog.Builder(this)
            .setTitle(g.name)
            .setMessage("Game file is linked. The engine that runs it comes in Phase 2.")
            .setPositiveButton("Play") { _, _ ->
                Toast.makeText(this, "Engine not connected yet (Phase 2)", Toast.LENGTH_LONG).show()
            }
            .setNegativeButton("Remove") { _, _ ->
                games.remove(g)
                saveGames()
                refresh()
            }
            .setNeutralButton("Close", null)
            .show()
    }

    private fun saveGames() {
        val arr = JSONArray()
        games.forEach { arr.put(JSONObject().put("name", it.name).put("uri", it.uri)) }
        getSharedPreferences("lib", MODE_PRIVATE).edit().putString("games", arr.toString()).apply()
    }

    private fun loadGames() {
        val s = getSharedPreferences("lib", MODE_PRIVATE).getString("games", null) ?: return
        val arr = JSONArray(s)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            games.add(Game(o.getString("name"), o.getString("uri")))
        }
    }
}
